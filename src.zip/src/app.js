import React , { Component} from 'react';
import { View } from 'react-native';
import firebase from 'firebase';
import { Header } from './components/common';
import  LoginForm from './components/LoginForm';



class App extends Component {
  componentWillMount(){
    firebase.initializeApp({
    apiKey:'AIzaSyB2slUrOxK4WL0ctqImo-1b1xPWfVSp4U8',
    authDomain: 'auth-84c67.firebaseapp.com',
    databaseURL: 'https://auth-84c67.firebaseio.com',
    storageBucket: 'auth-84c67.appspot.com',
    messagingSenderId: '383384429467'
  });
}

  render(){
    return(
      <View>
      <Header headerText="Authentication" />
      <LoginForm />
      </View>
    );
  }
}

export default App;
