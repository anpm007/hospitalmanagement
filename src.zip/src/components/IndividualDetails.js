import React , {PropTypes} from 'react';
import { Text,View,Image,Linking } from 'react-native';
import Card from './Card';
import CardSection from './CardSection';
import Button from './Button';


const con_now='';
const con_old='';

const IndividualDetails = ({list}) => {
  const thumbnail_image_vin = "https://i.kinja-img.com/gawker-media/image/upload/s--850PxImK--/c_scale,fl_progressive,q_80,w_800/18dtthtveanfmjpg.jpg";




  const { thumbnailStyle1 ,imageStyle1,headerTextStyle1, headerContentStyle1} = styles;

  const { title,artist,thumbnail_condition, thumb_miles ,image , url , model , psv , vin, miles_old,miles_new,condition_old,condition_now} = list;

  if (condition_old == 'Excellent'){
  con_old = 3;
    }
  else if (condition_old == 'Good') {
    con_old = 2;
  }
  else if (condition_old == 'Fair') {
    con_old = 1;
  };

  if (condition_now == 'Excellent'){
  con_now = 3;
    }
  else if (condition_now == 'Good') {
    con_now = 2;
  }
  else if (condition_now == 'Fair') {
    con_now = 1;
  }




  return(
    <Card>


          <CardSection>
          <View>
          <Text style={styles.headerTextStyle1}>{artist} {title} {model}</Text>
          <Image style = {styles.imageStyle1}  source = {{ uri:image }} />
          <Text><Image style={thumbnailStyle1} source = {{ uri:thumbnail_image_vin }}/> VIN : {vin}</Text>
          <Text><Image style={thumbnailStyle1} /> Miles : {miles_old} Kms</Text>
          <Text><Image style={thumbnailStyle1} /> Condition : {condition_now}</Text>
          <Text><Image style={thumbnailStyle1} /> Old Seller Value : $ {psv}</Text>
          <Text><Image style={thumbnailStyle1} /> Current Seller Value : $ {psv-(((miles_new-miles_old)*5)+((con_old-con_now)*100))}
          </Text>


          </View>
           </CardSection>


        </Card>
      );
    };


    const styles = {

      headerContentStyle1: {
        flexDirection: 'column',
        justifyContent: 'space-around'
      },

      headerTextStyle1: {
          fontSize:35
      },

      imageStyle1:{
        height:400,
          width:350

      },

      thumbnailStyle1:{
        height:18,
        width:30,
        borderColor: 'gray',
        borderWidth:1

      }


    };
    export  default IndividualDetails;
