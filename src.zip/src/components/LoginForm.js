import React, {Component} from 'react';
import {Text, TouchableHighlight, View} from 'react-native';
import firebase from 'firebase';
import { Header} from './common';


import { Button,Card,CardSection,Input,Spinner } from './common';

class LoginForm extends Component {

  constructor(props) {
    super(props);
    this.state = {email: '',password:'', error:'', loading:false};
    this.onButtonPress = this.onButtonPress.bind(this);
  }

  onButtonPress(){
    this.setState({error:'', loading:true});
    firebase.auth().signInWithEmailAndPassword(this.state.email,this.state.password)
    .then(this.onLoginSuccess.bind(this))

     .catch(() => {     // if user login failed then create new account
        firebase.auth().createUserWithEmailAndPassword(this.state.email,this.state.password)
        .then(this.onLoginSuccess.bind(this))
        .catch(this.onLoginFail.bind(this));

     });
  }

  onLoginFail(){
    this.setState({error:'Authentication Failed', loading: false});
  }

  onLoginSuccess(){
    this.setState({
      email:'',
      password:'',
      loading:false,
      error:''
    });
  }

  renderButton(){
    if (this.state.loading){
      return <Spinner size="small" />;
    }

    return(
      <TouchableHighlight onPress={this.onButtonPress}>
     <Text style={styles.textStyle}>Login</Text>
   </TouchableHighlight>
    );
  }

  render(){
    return(
      <View>
      <Card>
        <CardSection>
          <Input
          placeholder="user@gmail.com"
          label = 'Email :'
          value={this.state.email}
          onChangeText={email => this.setState({email})}
        />

        </CardSection>

        <CardSection>
        <Input
        secureTextEntry
        placeholder="*******"
        label = 'Password :'
        value={this.state.password}
        onChangeText={password => this.setState({password})}
        />

        </CardSection>

        <Text style={styles.errorTextStyle}>
        {this.state.error}
        </Text>

        <CardSection>
          {this.renderButton()}
        </CardSection>
      </Card>
      </View>
    )
  }
}

const styles={
  errorTextStyle:{
  fontSize:20,
  color:'red',
  alignSelf:'center'
},
textStyle:{
fontSize:20,
alignSelf:'center'
}



};

export default LoginForm;
