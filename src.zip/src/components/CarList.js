import React, {
    Component,
    PropTypes
} from 'react';
import {
    ScrollView,
    View,
    Text
} from 'react-native';
import axios from 'axios';
import CarDetail from './CarDetail';

let data =

    [{
        "title": "Bugati",
        "artist": "2000",
        "image": "https://cdn.pixabay.com/photo/2012/05/29/00/43/car-49278_960_720.jpg"
    }, {
        "title": "Lamborghini",
        "artist": "1997",
        "image": "http://www.iloveindia.com/cars/pics/lamborghini.jpg"
    }, {
        "title": "Mercedes",
        "artist": "1989",
        "image": "https://images.cardekho.com/car-images/carexteriorimages/large/Mercedes-Benz/Mercedes-Benz-GLA-Class/front-left-side-047.jpg"
    }, {
        "title": "Audi",
        "artist": "2004",
        "image": "https://s-media-cache-ak0.pinimg.com/originals/7c/c6/36/7cc636bf3d796e2e51dc833b6411e4c6.jpg"
    }, {
        "title": "Jaguar",
        "artist": "2015",
        "image": "http://www.marketing91.com/wp-content/uploads/2014/10/Marketing-mix-of-Jaguar.jpg"
    }];

class CarList extends Component {
    state = {
        carlist: []
    };


    componentWillMount() {

        // life cycle method
        axios.get('https://rallycoding.herokuapp.com/api/music_albums')
            .then(response => this.setState({
                carlist: data
            })); // once the http request is complete
        //console.log('in Car List');

    }

    renderList() {
        return this.state.carlist.map(list =>
            <
            CarDetail key = {
                list.title
            }
            list = {
                list
            }
            />
        );

    }


    render() { // must define render method while creating class
        return ( <
            ScrollView > {
                this.renderList()
            }

            <
            /ScrollView>
        );
    }

} // class do not requires ';''




export default CarList;



// Year Make Model
//PrivateSellerValue TradeInValue Condition Miles Date
