import React, {Component,PropTypes} from 'react';
import {ScrollView, View, Text} from 'react-native';
import{Router, Scene} from 'react-native-router-flux';
import axios from 'axios';
import CarDetail from './CarDetail';
import IndividualDetails from './IndividualDetails';

let data =

    [{
        "title": "Bugati",
        "artist": "2000",
        "model":"Veyron",
        "psv":20000,
        "vin":"6G1FT1E23561",
        "condition_old":"Fair",
        "condition_now":"Fair",
        "miles_old":2100,
        "miles_new":2200,
        "image": "https://cdn.pixabay.com/photo/2012/05/29/00/43/car-49278_960_720.jpg"
    }, {
        "title": "Lamborghini",
        "artist": "1997",
        "model":"V3",
          "psv":21000,
          "vin":"2G1FB1E23568",
          "condition_old":"Excellent",
          "condition_now":"Fair",
          "miles_old":2000,
          "miles_new":2400,
        "image": "https://media.caranddriver.com/images/media/51/lamborghini-2015-inline-photo-626127-s-original.jpg"
    }, {
        "title": "Mercedes",
        "artist": "1989",
        "model":"GLA",
          "psv":19000,
          "vin":"3G1GB1E54567",
          "condition_old":"Good",
          "condition_now":"Fair",
          "miles_old":2520,
          "miles_new":2900,
         "image": "https://images.cardekho.com/car-images/carexteriorimages/large/Mercedes-Benz/Mercedes-Benz-GLA-Class/front-left-side-047.jpg"
    }, {
        "title": "Audi",
        "artist": "2004",
        "model":"A7",
          "psv":18000,
          "vin":"9G1GRT23178",
          "condition_old":"Fair",
          "condition_now":"Fair",
          "miles_old":1900,
          "miles_new":2400,
        "image": "https://s-media-cache-ak0.pinimg.com/originals/7c/c6/36/7cc636bf3d796e2e51dc833b6411e4c6.jpg"
    }, {
        "title": "Jaguar",
        "artist": "2015",
        "model":"XJ",
          "psv":20050,
          "vin":"5G1FL1E28561",
          "condition_old":"Excellent",
          "condition_now":"Fair",
          "miles_old":1500,
          "miles_new":1800,
        "image": "https://images.cardekho.com/images/car-images/large/Jaguar/Jaguar-F-Type/Salsa-Red-swatch.jpg"
    }];

class CarList extends Component {
    state = {
        carlist: []
    };


    componentWillMount() {

        // life cycle method
        axios.get('https://rallycoding.herokuapp.com/api/music_albums')
            .then(response => this.setState({
                carlist: data
            }));
        //console.log('in Car List');

    }

    renderList() {

        return this.state.carlist.map(list =>
            <CarDetail key = {list.title}
            list = {list}/>
        );
    }


    render() {
        return ( <ScrollView >
          {this.renderList()}
            </ScrollView>


        );
    }

}




export default CarList;
