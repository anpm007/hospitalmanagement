import React , {Component, PropTypes} from 'react';
import { Text,View,Image,Linking, TouchableHighlight } from 'react-native';
import { Actions } from 'react-native-router-flux';

import Card from './Card';
import CardSection from './CardSection';
import Button from './Button';

const con_now='';
const con_old='';
const thumbnail_image_vin = "https://i.kinja-img.com/gawker-media/image/upload/s--850PxImK--/c_scale,fl_progressive,q_80,w_800/18dtthtveanfmjpg.jpg";

class CarDetail extends Component {

  constructor(props) {
    super(props);
  }

  loadIndividualDetails () {
    Actions.individualDetails({list: this.props.list});
  }

  render () {

    const { title,artist,condition_now,image,model,psv,vin,miles_new,miles_old,condition_old} = this.props.list;
    const { thumbnailStyle1,imageStyle1,headerTextStyle1,headerContentStyle1,thumbnailStyle , imageStyle,  headerContentStyle, thumbnailContainerStyle ,headerTextStyle} = styles;

    if (condition_old == 'Excellent'){
    con_old = 3;
      }
    else if (condition_old == 'Good') {
      con_old = 2;
    }
    else if (condition_old == 'Fair') {
      con_old = 1;
    };

    if (condition_now == 'Excellent'){
    con_now = 3;
      }
    else if (condition_now == 'Good') {
      con_now = 2;
    }
    else if (condition_now == 'Fair') {
      con_now = 1;
    }


      return(
        <Card>
        <CardSection>
        <View style ={headerContentStyle}>
          <Text style={headerTextStyle}>{artist} {title} {model} </Text>
        <Text>PSV : {psv}</Text>
          </View>
         </CardSection>

         <CardSection>
         <Image style={imageStyle} source = {{ uri:image }} />
         </CardSection>

         <CardSection>
         <TouchableHighlight onPress={this.loadIndividualDetails.bind(this)}>
         <Text>View Details</Text>
         </TouchableHighlight>
         </CardSection>
        </Card>
      );
  }
};




const styles = {
  headerContentStyle: {
      flexDirection: 'column',
      justifyContent: 'space-around'

  },


  headerTextStyle: {
    fontSize:18

  },

  thumbnailStyle: {
    height:50,
    width:50,
    borderColor: 'red',
    borderWidth:2
  },

  thumbnailContainerStyle: {
    justifyContent : 'center',
    alignItems: 'center',
    marginLeft: 10,
    marginRight: 10
  },

  imageStyle: {
    height:300,
    flex:1,
    width:null
  },
  headerContentStyle1: {
    flexDirection: 'column',
    justifyContent: 'space-around'
  },

  headerTextStyle1: {
      fontSize:35
  },

  imageStyle1:{
    height:500,
    flex:1,
    width:350

  },

  thumbnailStyle1:{
    height:20,
    width:30,
    borderWidth:1

  }



};

export  default CarDetail;
